## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)
library(binomial)

## ------------------------------------------------------------------------
bin_choose(n = 5, k = 2)
bin_choose(5, 0) 
bin_choose(5, 1:3)

## ------------------------------------------------------------------------
## calculate the probability on success times under trials times within certain successful probabilities
bin_probability(success = 2, trials = 5, prob = 0.5)
bin_probability(success = 1:3, trials = 5, prob = 0.5)


## ------------------------------------------------------------------------
bin_distribution(trials = 5, prob = 0.5)
dis1 <- bin_distribution(trials = 5, prob = 0.5) 
plot(dis1)

## ------------------------------------------------------------------------
dis2 <- bin_cumulative(trials = 5, prob = 0.5)
plot(dis2)

## ------------------------------------------------------------------------
bin_variable(trials = 10, p = 0.5)
summary(bin_variable(trials = 10, p = 0.5))

## ------------------------------------------------------------------------
bin_mean(10, 0.3)
bin_variance(10, 0.3)
bin_mode(10, 0.3)
bin_skewness(10, 0.3)
bin_kurtosis(10, 0.3)

